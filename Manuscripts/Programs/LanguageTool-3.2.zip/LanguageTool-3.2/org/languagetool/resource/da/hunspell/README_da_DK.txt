Stavekontrolden - Danish dictionary files for Hunspell
Version 2.3 - 2015-11-15
da_DK.dic, da_DK.aff: © 2015 Foreningen for frit tilgængelige sprogværktøjer - http://www.stavekontrolden.dk
These files are published under the following open source licenses:

GNU GPL version 2.0
GNU LGPL version 2.1
Mozilla MPL version 1.1

This dictionary is based on data from Det Danske Sprog- og Litteraturselskab
(The Danish Society for Language and Literature), http://www.dsl.dk.
and contributes form voluntary community members.
