Spellchecker
------------

This is Spellchecker developed and maintained in project sk-spell (http://sk-spell.sk.cx/)

Data are released under these licenses (you can select one):
  * The GNU General Public License (GPL) Version 2, June 1991
  * GNU Lesser General Public License Version 2.1, February 1999
  * Mozilla Public License 1.1 (MPL 1.1)

Further information are available (in Slovak):
	http://sk-spell.sk.cx/ispell-sk
	http://sk-spell.sk.cx/myspell-sk
	http://sk-spell.sk.cx/aspell-sk
	http://sk-spell.sk.cx/hunspell-sk

